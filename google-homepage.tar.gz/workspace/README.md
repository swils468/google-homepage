# google-homepage
html practice recreating google homepage (odin project)
